define( function ( require ) {

	"use strict";

	return {
		app_slug : 'neshaneh',
		wp_ws_url : 'http://neshaneh.info/wp-appkit-api/neshaneh',
		wp_url : 'http://neshaneh.info',
		theme : 'q-android',
		version : '1',
		app_type : 'phonegap-build',
		app_title : 'نشانه | ارتباط | راهبرد',
		app_platform : 'android',
		app_path: '',
		gmt_offset : 4,
		debug_mode : 'off',
		auth_key : 'x%VF}k]ykEbu6dUT+r&;+lzCW5W<0Y >q-Ag;fMY+)_:)D`;T[G0k9F3o#9tY*aa',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
